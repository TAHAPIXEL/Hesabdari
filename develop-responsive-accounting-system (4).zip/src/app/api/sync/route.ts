import { db } from "@/db";
import {
  contacts,
  expenses,
  invoices,
  ledgerEntries,
  products,
  receipts,
  settings,
} from "@/db/schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const num = (v: unknown) => (v === null || v === undefined ? 0 : Number(v));
const now = () => new Date().toISOString();

type Row = Record<string, unknown>;

function serialize(table: string, rows: Row[]) {
  const numericCols: Record<string, string[]> = {
    products: ["cost", "price", "stock", "minStock"],
    invoices: ["discount", "vat", "total", "paid"],
    expenses: ["amount"],
    receipts: ["amount"],
    ledgerEntries: ["amount"],
  };
  const cols = numericCols[table] ?? [];
  return rows.map((r) => {
    const out: Row = { ...r };
    for (const c of cols) if (c in out) out[c] = num(out[c]);
    return out;
  });
}

/** دریافت کل داده‌ها از سرور (فقط هنگامی که سرور در دسترس است). */
export async function GET() {
  try {
    const [p, c, i, e, l, s, rc] = await Promise.all([
      db.select().from(products),
      db.select().from(contacts),
      db.select().from(invoices),
      db.select().from(expenses),
      db.select().from(ledgerEntries),
      db.select().from(settings),
      db.select().from(receipts),
    ]);
    return Response.json({
      ok: true,
      products: serialize("products", p as Row[]),
      contacts: serialize("contacts", c as Row[]),
      invoices: serialize("invoices", i as Row[]),
      expenses: serialize("expenses", e as Row[]),
      ledgerEntries: serialize("ledgerEntries", l as Row[]),
      settings: serialize("settings", s as Row[]),
      receipts: serialize("receipts", rc as Row[]),
      serverTime: now(),
    });
  } catch {
    return Response.json({ ok: false, error: "db unavailable" }, { status: 503 });
  }
}

/** ذخیره کل وضعیت برنامه (upsert با آخرین نوشته برنده). */
export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "bad json" }, { status: 400 });
  }
  const ts = now();
  try {
    await db.transaction(async (tx) => {
      const listOf = (k: string) => (Array.isArray(body[k]) ? (body[k] as Row[]) : []);

      for (const r of listOf("products")) {
        await tx
          .insert(products)
          .values({
            id: String(r.id),
            name: String(r.name ?? ""),
            barcode: (r.barcode as string) ?? null,
            category: (r.category as string) ?? null,
            unit: (r.unit as string) ?? "عدد",
            cost: String(num(r.cost)),
            price: String(num(r.price)),
            stock: String(num(r.stock)),
            minStock: String(num(r.minStock)),
            vatable: r.vatable !== false,
            updatedAt: ts,
          })
          .onConflictDoUpdate({
            target: products.id,
            set: {
              name: String(r.name ?? ""),
              barcode: (r.barcode as string) ?? null,
              category: (r.category as string) ?? null,
              unit: (r.unit as string) ?? "عدد",
              cost: String(num(r.cost)),
              price: String(num(r.price)),
              stock: String(num(r.stock)),
              minStock: String(num(r.minStock)),
              vatable: r.vatable !== false,
              updatedAt: ts,
            },
          });
      }

      for (const r of listOf("contacts")) {
        await tx
          .insert(contacts)
          .values({
            id: String(r.id),
            name: String(r.name ?? ""),
            kind: String(r.kind ?? "customer"),
            phone: (r.phone as string) ?? null,
            note: (r.note as string) ?? null,
            updatedAt: ts,
          })
          .onConflictDoUpdate({
            target: contacts.id,
            set: {
              name: String(r.name ?? ""),
              kind: String(r.kind ?? "customer"),
              phone: (r.phone as string) ?? null,
              note: (r.note as string) ?? null,
              updatedAt: ts,
            },
          });
      }

      for (const r of listOf("invoices")) {
        const values = {
          no: String(r.no ?? ""),
          kind: String(r.kind ?? "sale"),
          date: String(r.date ?? ts),
          contactId: (r.contactId as string) ?? null,
          contactName: (r.contactName as string) ?? null,
          items: JSON.stringify(Array.isArray(r.items) ? r.items : []),
          discount: String(num(r.discount)),
          vat: String(num(r.vat)),
          total: String(num(r.total)),
          paid: String(num(r.paid)),
          method: (r.method as string) ?? "cash",
          note: (r.note as string) ?? null,
          updatedAt: ts,
        };
        await tx
          .insert(invoices)
          .values({ id: String(r.id), ...values })
          .onConflictDoUpdate({ target: invoices.id, set: values });
      }

      for (const r of listOf("expenses")) {
        const values = {
          date: String(r.date ?? ts),
          title: String(r.title ?? ""),
          category: (r.category as string) ?? null,
          amount: String(num(r.amount)),
          account: (r.account as string) ?? null,
          updatedAt: ts,
        };
        await tx
          .insert(expenses)
          .values({ id: String(r.id), ...values })
          .onConflictDoUpdate({ target: expenses.id, set: values });
      }

      for (const r of listOf("receipts")) {
        const values = {
          date: String(r.date ?? ts),
          contactId: (r.contactId as string) ?? null,
          dir: String(r.dir ?? "in"),
          amount: String(num(r.amount)),
          method: (r.method as string) ?? "cash",
          note: (r.note as string) ?? null,
          updatedAt: ts,
        };
        await tx
          .insert(receipts)
          .values({ id: String(r.id), ...values })
          .onConflictDoUpdate({ target: receipts.id, set: values });
      }

      for (const r of listOf("ledgerEntries")) {
        const values = {
          date: String(r.date ?? ts),
          kind: String(r.kind ?? "other"),
          title: String(r.title ?? ""),
          contactId: (r.contactId as string) ?? null,
          amount: String(num(r.amount)),
          refId: (r.refId as string) ?? null,
          updatedAt: ts,
        };
        await tx
          .insert(ledgerEntries)
          .values({ id: String(r.id), ...values })
          .onConflictDoUpdate({ target: ledgerEntries.id, set: values });
      }

      const st = body.settings;
      if (st && typeof st === "object") {
        await tx
          .insert(settings)
          .values({ key: "app", value: st, updatedAt: ts })
          .onConflictDoUpdate({ target: settings.key, set: { value: st, updatedAt: ts } });
      }
    });
    return Response.json({ ok: true, at: ts });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
