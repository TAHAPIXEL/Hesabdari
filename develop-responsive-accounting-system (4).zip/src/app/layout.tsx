import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "دفتر — سامانه حسابداری آفلاین",
  description:
    "سامانه حسابداری و انبار تک‌فایل، کاملاً آفلاین، با اسکن بارکد و گزارش‌های مالی.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
